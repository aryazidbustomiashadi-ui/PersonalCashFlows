package com.example.personalcashflow

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF172033)
private val Green = Color(0xFF16866A)
private val Red = Color(0xFFD85B68)
private val Soft = Color(0xFFF4F6F8)

data class Transaction(
    val id: Long,
    val title: String,
    val category: String,
    val amount: Long,
    val type: String,
    val date: String
)

class FinanceDb(context: Context) : SQLiteOpenHelper(context, "cashflow.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                amount INTEGER NOT NULL,
                type TEXT NOT NULL,
                date TEXT NOT NULL
            )
        """.trimIndent())
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(title: String, category: String, amount: Long, type: String) {
        val values = ContentValues().apply {
            put("title", title); put("category", category)
            put("amount", amount); put("type", type)
            put("date", SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date()))
        }
        writableDatabase.insert("transactions", null, values)
    }

    fun all(): List<Transaction> {
        val result = mutableListOf<Transaction>()
        readableDatabase.rawQuery(
            "SELECT id,title,category,amount,type,date FROM transactions ORDER BY id DESC", null
        ).use { c ->
            while (c.moveToNext()) result += Transaction(
                c.getLong(0), c.getString(1), c.getString(2),
                c.getLong(3), c.getString(4), c.getString(5)
            )
        }
        return result
    }
}

private fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value)
        .replace(",00", "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = FinanceDb(this)
        setContent { CashFlowApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashFlowApp(db: FinanceDb) {
    var transactions by remember { mutableStateOf(db.all()) }
    var showAdd by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Beranda") }

    val income = transactions.filter { it.type == "Pemasukan" }.sumOf { it.amount }
    val expense = transactions.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
    val balance = income - expense

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, background = Soft, surface = Color.White,
            onBackground = Ink, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Soft,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = Green, contentColor = Color.White
                ) { Text("+", fontSize = 28.sp) }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Beranda", "Transaksi", "Anggaran").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(when(tab) { "Beranda" -> "⌂"; "Transaksi" -> "↕"; else -> "▤" }, fontSize = 20.sp) },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "Transaksi" -> TransactionList(transactions, Modifier.padding(padding))
                "Anggaran" -> BudgetScreen(Modifier.padding(padding))
                else -> Dashboard(
                    balance, income, expense, transactions,
                    Modifier.padding(padding),
                    onAdd = { showAdd = true }
                )
            }
        }

        if (showAdd) {
            AddTransactionDialog(
                onDismiss = { showAdd = false },
                onSave = { title, category, amount, type ->
                    db.add(title, category, amount, type)
                    transactions = db.all()
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun Dashboard(
    balance: Long, income: Long, expense: Long,
    transactions: List<Transaction>, modifier: Modifier = Modifier,
    onAdd: () -> Unit
) {
    LazyColumn(
        modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
    ) {
        item {
            Text("Personal Cash Flow", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Ringkasan keuanganmu", color = Color.Gray, fontSize = 13.sp)
        }
        item {
            Column(
                Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(22.dp)).padding(22.dp)
            ) {
                Text("TOTAL SALDO", color = Color(0xFFBFC9D8), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text(rupiah(balance), color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("↑ Pemasukan", color = Color(0xFF9DE0C5), fontSize = 12.sp)
                        Text(rupiah(income), color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("↓ Pengeluaran", color = Color(0xFFFFB6BF), fontSize = 12.sp)
                        Text(rupiah(expense), color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("＋", "Tambah transaksi", Modifier.weight(1f), onAdd)
                QuickAction("▤", "Lihat riwayat", Modifier.weight(1f)) {}
            }
        }
        item {
            Text("Transaksi terbaru", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (transactions.isEmpty()) {
            item {
                Text(
                    "Belum ada transaksi. Tekan tombol + untuk mencatat pemasukan atau pengeluaran.",
                    color = Color.Gray, modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(transactions.take(5)) { TransactionRow(it) }
        }
    }
}

@Composable
fun QuickAction(symbol: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, color = Color.White, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(symbol, color = Green, fontSize = 24.sp)
            Text(label, fontWeight = FontWeight.Medium, fontSize = 13.sp)
        }
    }
}

@Composable
fun TransactionList(transactions: List<Transaction>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Riwayat transaksi", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        if (transactions.isEmpty()) Text("Belum ada transaksi.", color = Color.Gray)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transactions) { TransactionRow(it) }
        }
    }
}

@Composable
fun TransactionRow(item: Transaction) {
    Surface(color = Color.White, shape = RoundedCornerShape(14.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.SemiBold)
                Text("${item.category} • ${item.date}", color = Color.Gray, fontSize = 12.sp)
            }
            Text(
                (if (item.type == "Pemasukan") "+ " else "- ") + rupiah(item.amount),
                color = if (item.type == "Pemasukan") Green else Red,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BudgetScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Anggaran bulanan", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Fitur pengaturan batas pengeluaran per kategori akan ditambahkan pada versi berikutnya.", color = Color.Gray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Pengeluaran") }
    var category by remember { mutableStateOf("Makanan") }
    val categories = if (type == "Pemasukan")
        listOf("Uang saku", "Gaji", "Hadiah", "Lainnya")
    else listOf("Makanan", "Transportasi", "Pendidikan", "Hiburan", "Belanja", "Tagihan", "Lainnya")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah transaksi", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == "Pengeluaran", onClick = { type = "Pengeluaran"; category = "Makanan" }, label = { Text("Pengeluaran") })
                    FilterChip(selected = type == "Pemasukan", onClick = { type = "Pemasukan"; category = "Uang saku" }, label = { Text("Pemasukan") })
                }
                OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
                OutlinedTextField(
                    amount, { amount = it.filter(Char::isDigit) },
                    label = { Text("Nominal (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Text("Kategori", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.take(3).forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 11.sp) })
                    }
                }
                if (categories.size > 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        categories.drop(3).forEach { c ->
                            FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 11.sp) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val value = amount.toLongOrNull()
                    if (title.isNotBlank() && value != null && value > 0) onSave(title.trim(), category, value, type)
                },
                enabled = title.isNotBlank() && (amount.toLongOrNull() ?: 0L) > 0
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
